**InfectCord - Patch Notes - Version 1.1**

- Fixed critical `nuke` cmd bug
- Added global msges deletion logger via webhooks

**InfectCord Patch Notes - Version 2.0**

- Implemented a license system and encrypted the code for enhanced security
- Added AFK cmnds

**InfectCord Patch Notes - Version 2.x**
- Upgraded `AFK`, `Mute`,`Spam` cmds
- Added 2 Wizz Cmds ( Spam Channels, DM Cleaner )

**Infectcord Patch Notes - Version 2.x**

- Added `Nitro sniper` with webhook notify
- Snipe `deleted msges`
- ARs `trigger deletion` on cmd execution
- Server `Vanity` checker is added now