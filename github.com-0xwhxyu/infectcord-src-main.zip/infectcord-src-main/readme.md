# Infectcord src
# thanks [kek](https://discord.gg/craks) for giving me the files for me to deobf

Thank you for choosing Infect Cord x2 Official Version! The Only Premium Selfbot In This Scene !!

## Getting Started

1. **Installation:**
   - Run `install.bat` (Windows) or install dependencies using `pip install -r infreq.txt` before starting the bot

2. **Configure `config.ini`:**
   - Edit `config.ini` file with the following content:

   ```ini
   [InfectCord]
   token = (Your Selfbot token)
   userid = (Your user ID)
   prefix = # Bot command prefix; leave empty for no prefix
   licensekey = (Your license key)

   [DeleteMsgWebhook]
   deleted_logs = False
   deletemsgwebhookurl =

   [SniperWebhook]
   sniperwebhookurl =
   
   [CryptoWebhook]
   cryptowebhookurl = 

   [Misc]
   webhookurl = 
   ```
- Optional Configurations:
- Modify the values in config.ini as needed.

## Usage

- Execute `python3 main.py` to start the bot.
- For Windows users, run `start.bat` for a convenient start.

## Additional Information

- Join the official server [here](https://discord.gg/chiterl) for bug fixes, updates, and support
- Review the Terms of Service (TOS) provided in the AutoBuy.
- Sharing, reselling, or leaking this bot is strictly prohibited. No support or updates will be provided in such cases.

Feel free to explore the features and enjoy using Infect Cord x2 Official Version!
